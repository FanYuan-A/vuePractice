<template>
    <div class="two">
        <el-button type="primary" v-on:click="btnClick" v-bind:states="states">打印{{classStates}}{{states}}</el-button>
    </div>
</template>
<script>
export default {
    data:function(){
        return {
            states:this.classStates
        }
    },
    name:'two',
    props:{
        classStates:Boolean
    },
    methods:{
        btnClick:function(){
            this.classStates= !this.classStates;
            this.$emit("statesChanged",this.states);
        }
    }
}
</script>

<style scoped>

</style>